﻿export class LoginModel
{
	public email: string;
	public password: string;
	public remember: boolean;
}

export class RegisterModel
{
	public email: string;
	public password: string;
	public confirmPassword: string;
}